This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Charlie house party

Charlie house party is personal side project of Petr Hoskovec. 
Feel free to read thru or suggest any change.
I am allways up to chat. 
[EMAIL](ihoskovecpetr@gmail.com)
